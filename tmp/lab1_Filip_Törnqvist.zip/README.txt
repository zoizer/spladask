Förbättringar:
1. När man skriver in text och därefter tappar focus genom att klicka på en annan kontakt sparas inte texten.
2. När man har en TextField selectad och därefter klickar på en ny kontakt så selectas enbart den nedersta kontakten
3. Man hade kunnat behöva sätta en minimum storlek på fönstret så att oberoende på storleken man valt ska allt fortfarande vara användbart.
4. Man hade kunnat sätta en minimum storlek på de olika sidor i splitpane, eller någon form av indikator att den går att dra ut om den är minimerad.
5. När en kontakt inte är selectad bör TextFields och allt på högersidan om splitpane vara dolt eller indikera att inget är selectat.
6. Alla TextField input i högersidan av splitpane bör ha specifikerat om enbart tecken eller nummer eller en blandning får användas. Tex, telefonnummer behöver inte bokstäver., Email har en viss struktur etc.
7. Rent programmatiskt skulle jag vilja see Ny kontakt/ta bort i menyn var samma som object som respective knapp i ToolBar'en. dvs, ett object som renderas på ett sätt om den tilläggs i en meny och ett helt annat om den tilläggs i toolbar'en.
   På så sätt minimera kod duplikering.