/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recipesearch;

import java.util.Arrays;
import java.util.List;
import se.chalmers.ait.dat215.lab2.Recipe;
import se.chalmers.ait.dat215.lab2.RecipeDatabase;
import se.chalmers.ait.dat215.lab2.SearchFilter;

/**
 *
 * @author Zoizer
 */
public class RecipeBackendController {

    private final RecipeDatabase db = RecipeDatabase.getSharedInstance();
    private final SearchFilter sf = new SearchFilter(null, 0, null, 0, null);
    
    public static final String[] CUISINES = {"Sverige", "Grekland", "Indien", "Asien", "Afrika", "Frankrike"};
    public static final String[] MAIN_INGREDIENTS = {"Kött", "Fisk", "Kyckling", "Vegetarisk"};
    public static final String[] DIFFICULTIES = {"Lätt", "Mellan", "Svår"};

    public List<Recipe> getRecipes() {
        return db.search(sf);
    }

    public void setCuisine(String cuisine) {
        if (Arrays.asList(CUISINES).contains(cuisine)) sf.setCuisine(cuisine);
        else sf.setCuisine(null);
    }

    public void setMainIngredient(String mainIngredient) {
        if (Arrays.asList(MAIN_INGREDIENTS).contains(mainIngredient)) sf.setMainIngredient(mainIngredient);
        else sf.setMainIngredient(null);
    }

    public void setDifficulty(String difficulty) {
        if (Arrays.asList(DIFFICULTIES).contains(difficulty)) sf.setDifficulty(difficulty);
        else sf.setDifficulty(null);
    }

    public void setMaxPrice(int maxPrice) {
        if (maxPrice > 0) sf.setMaxPrice(maxPrice);
        else sf.setMaxPrice(0);
    }

    public void setMaxTime(int maxTime) {
        if ((maxTime >= 10) && (maxTime <= 150) && (maxTime % 10 == 0)) sf.setMaxTime(maxTime);
        else sf.setMaxTime(0);
    }
}
