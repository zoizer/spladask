/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recipesearch;

import java.io.IOException;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import se.chalmers.ait.dat215.lab2.Recipe;

/**
 *
 * @author Zoizer
 */
public class RecipeListItem extends AnchorPane {

    private final RecipeSearchController parentController;
    private final Recipe recipe;
    @FXML
    private ImageView recipeListItemImage;
    @FXML
    private Label recipeListItemLabel;

    public RecipeListItem(Recipe recipe, RecipeSearchController recipeSearchController) {
        this.recipe = recipe;
        this.parentController = recipeSearchController;

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("recipe_listitem.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        recipeListItemImage.setImage(recipe.getFXImage());
        recipeListItemLabel.setText(recipe.getName());
    }

    @FXML
    protected void onClick(Event event) {
        parentController.openRecipeView(recipe);
    }
}
