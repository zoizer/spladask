package recipesearch;

import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import se.chalmers.ait.dat215.lab2.Recipe;
import se.chalmers.ait.dat215.lab2.RecipeDatabase;

public class RecipeSearchController implements Initializable {

    private RecipeDatabase db = RecipeDatabase.getSharedInstance();
    private RecipeBackendController backend = new RecipeBackendController();
    private Map<String, RecipeListItem> recipeListItemMap = new HashMap<String, RecipeListItem>();

    @FXML
    private FlowPane searchResultFlowPane;
    @FXML
    private ComboBox searchFilterMainIngredientComboBox;
    @FXML
    private ComboBox searchFilterCuisineComboBox;
    @FXML
    private RadioButton searchFilterDifficultyAllRadioButton;
    @FXML
    private RadioButton searchFilterDifficultyEasyRadioButton;
    @FXML
    private RadioButton searchFilterDifficultyMediumRadioButton;
    @FXML
    private RadioButton searchFilterDifficultyHardRadioButton;
    @FXML
    private Spinner searchFilterPriceSpinner;
    @FXML
    private Slider searchFilterTimeSlider;
    @FXML
    private Label searchFilterTimeLabel;
    @FXML
    private ImageView recipeDetailImage;
    @FXML
    private Label recipeDetailLabel;
    @FXML
    private AnchorPane recipeDetailPane;
    @FXML
    private SplitPane searchPane;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ComboBox ingredient = searchFilterMainIngredientComboBox;
        ComboBox cuisine = searchFilterCuisineComboBox;
        RadioButton dAll = searchFilterDifficultyAllRadioButton;
        RadioButton dEasy = searchFilterDifficultyEasyRadioButton;
        RadioButton dMedium = searchFilterDifficultyMediumRadioButton;
        RadioButton dHard = searchFilterDifficultyHardRadioButton;
        Spinner price = searchFilterPriceSpinner;
        Slider sTime = searchFilterTimeSlider;
        Label lTime = searchFilterTimeLabel;

        ingredient.getItems().addAll(Arrays.asList(backend.MAIN_INGREDIENTS));
        ingredient.getSelectionModel().select(backend.MAIN_INGREDIENTS[0]);
        ingredient.getSelectionModel().selectedItemProperty().addListener((ChangeListener<String>) (ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            backend.setMainIngredient(newValue);
            updateRecipeList();
        });

        cuisine.getItems().addAll(Arrays.asList(backend.CUISINES));
        cuisine.getSelectionModel().select(backend.CUISINES[0]);
        cuisine.getSelectionModel().selectedItemProperty().addListener((ChangeListener<String>) (ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            backend.setCuisine(newValue);
            updateRecipeList();
        });

        ToggleGroup tog = new ToggleGroup();
        dAll.setToggleGroup(tog);
        dEasy.setToggleGroup(tog);
        dMedium.setToggleGroup(tog);
        dHard.setToggleGroup(tog);

        dAll.setSelected(true);

        tog.selectedToggleProperty().addListener((ChangeListener<Toggle>) (ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) -> {
            if (tog.getSelectedToggle() != null) {
                RadioButton selected = (RadioButton) tog.getSelectedToggle();
                if (selected == null) {
                    return;
                }
                backend.setDifficulty(selected.getText());
                updateRecipeList();
            }
        });

        SpinnerValueFactory<Integer> fac = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, Integer.MAX_VALUE, 0, 10);
        price.setValueFactory(fac);
        price.valueProperty().addListener((ChangeListener<Integer>) (ObservableValue<? extends Integer> observable, Integer oldValue, Integer newValue) -> {
            if (newValue == null) {
                return;
            }
            backend.setMaxPrice(newValue);
            updateRecipeList();
        });

        price.focusedProperty().addListener((ChangeListener<Boolean>) (ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) -> {
            if (newValue == null || newValue) {
                //focusgained - do nothing
            } else {
                Integer value;
                try {
                    value = Integer.valueOf(price.getEditor().getText());
                } catch (NumberFormatException e) {
                    return;
                }
                backend.setMaxPrice(value);
                updateRecipeList();
            }
        });

        sTime.valueProperty().addListener((ChangeListener<Number>) (ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
            if (newValue != null && !newValue.equals(oldValue)) {
                if (!sTime.isValueChanging()) {
                    backend.setMaxTime(newValue.intValue());
                    updateRecipeList();
                }
                lTime.setText("" + newValue.intValue() + " minuter");
            }
        });

        for (Recipe recipe : backend.getRecipes()) {
            if (recipe == null) {
                continue;
            }
            RecipeListItem recipeListItem = new RecipeListItem(recipe, this);
            recipeListItemMap.put(recipe.getName(), recipeListItem);
        }

        updateRecipeList();
    }

    private void updateRecipeList() {
        searchResultFlowPane.getChildren().clear();
        List<Recipe> r = backend.getRecipes();
        for (Recipe e : r) {
            if (e == null) {
                continue;
            }
            searchResultFlowPane.getChildren().add(recipeListItemMap.get(e.getName()));
        }
    }

    private void populateRecipeDetailView(Recipe r) {
        if (r == null) {
            return;
        }
        recipeDetailLabel.setText(r.getName());
        recipeDetailImage.setImage(r.getFXImage());
    }

    @FXML
    public void closeRecipeView() {
        searchPane.toFront();
    }

    public void openRecipeView(Recipe recipe) {
        if (recipe == null) {
            return;
        }
        populateRecipeDetailView(recipe);
        recipeDetailPane.toFront();
    }
}
