Kontroller:
all input är safe som går genom RecipeBackendController.
Om en sträng stämmer överäns med de tillåtna, används den, annars används null (även om input är null så blir output null)
maxprice är fungerar så länge det är över eller lika med noll (instruktionerna sa över noll vilket gick imot andra instruktioner som sa att 0 ==> 0, därav OK för in >= 0)
 - om det inte stämmer blir det noll, vilket är OK.
maxTime accepterar enbart 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150. allt annat ger noll.

ie. all input är alltid bra där.

RecipeSearchController försäkrar sig om att alltid allt finns när det används (när det är relevant).
Därav är den också någolunda säker, för att göra den säkrare krävs en bättre förståelse för backenden och javafx.
(Att ge input till spinner som inte är en integer ger ett exception i någon av basklasserna, 
kan ej säga om det helt går att fixa för oss, men möjligt att vi kanske kan göra något filter 
som enbart tillåter nummer input till spinnern)


Förbättringar:
Tillåt Huvudingrediens och kök att vara tom eller "Alla".
Förtydliga hur väl ett recept matchar.
Gör allt locale baserat
Max pris hade möjligtvist
Ersätta spinner med något som fungerar för allt input.