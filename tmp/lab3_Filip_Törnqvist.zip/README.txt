LAB2 Förbättringar:
Tillåt Huvudingrediens och kök att vara tom eller "Alla". 	- OK
Förtydliga hur väl ett recept matchar.						- EJ OK
Gör allt locale baserat										- EJ OK
Ersätta spinner med något som fungerar för allt input.		- EJ OK

LAB3 Förbättringar:
Förtydliga hur väl ett recept matchar.
Gör allt locale baserat
Ersätta spinner med något som fungerar för allt input.
Bättre hantering av resize, ta bort alla konstanta pixelstorlekar och ersätt med abstrakta storlekar samt abstrakta positioner.
Bättre feedback på att man kan gå tilbaka från detail view genom att klicka på den utgråade kanten.
Bättre hantering för hur object ska interagera med varandra när resize sker, dvs om objekt kan vara över varandra/cropas/stanna där de är.