/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recipesearch;

import java.io.IOException;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.AnchorPane;
import se.chalmers.ait.dat215.lab2.Recipe;

/**
 *
 * @author Zoizer
 */
public class RecipeListItem extends AnchorPane {

    private final RecipeSearchController parentController;
    private final Recipe recipe;
    @FXML
    private ImageView recipeListItemImage;
    @FXML
    private ImageView recipeListItemFlag;
    @FXML
    private Label recipeListItemLabel;
    @FXML
    private ImageView recipeListItemIngredient;
    @FXML
    private ImageView recipeListItemDifficulty;
    @FXML
    private Label recipeListItemTime;
    @FXML
    private Label recipeListItemPrice;
    @FXML
    private Label recipeListItemDescription;
    @FXML
    private ImageView recipeListItemTimer;

    public RecipeListItem(Recipe recipe, RecipeSearchController recipeSearchController) {
        this.recipe = recipe;
        this.parentController = recipeSearchController;

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("recipe_listitem.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        recipeListItemImage.setImage(parentController.getSquareImage(recipe.getFXImage()));
        recipeListItemLabel.setText(recipe.getName());
        recipeListItemFlag.setImage(parentController.getCuisineImage(recipe.getCuisine()));
        recipeListItemIngredient.setImage(parentController.getIngredientImage(recipe.getMainIngredient()));
        recipeListItemDescription.setText(recipe.getInstruction());
        recipeListItemDifficulty.setImage(parentController.getDifficultyImage(recipe.getDifficulty()));
        recipeListItemTime.setText("" + recipe.getTime() + " minuter");
        recipeListItemTimer.setImage(parentController.getTimerImage());
        recipeListItemPrice.setText("" + recipe.getPrice() + " kr");
    }

    @FXML
    protected void onClick(Event event) {
        parentController.openRecipeView(recipe);
    }
}
