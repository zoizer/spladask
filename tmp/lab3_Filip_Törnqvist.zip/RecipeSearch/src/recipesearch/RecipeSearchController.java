package recipesearch;

import java.io.File;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.util.Callback;
import se.chalmers.ait.dat215.lab2.Ingredient;
import se.chalmers.ait.dat215.lab2.Recipe;
import se.chalmers.ait.dat215.lab2.RecipeDatabase;

public class RecipeSearchController implements Initializable {

    private static final String INGREDIENT_DEFAULT = "Visa alla";
    private static final String CUISINE_DEFAULT = "Visa alla";

    private RecipeDatabase db = RecipeDatabase.getSharedInstance();
    private RecipeBackendController backend = new RecipeBackendController();
    private Map<String, RecipeListItem> recipeListItemMap = new HashMap<String, RecipeListItem>();

    @FXML
    private FlowPane searchResultFlowPane;
    @FXML
    private ComboBox searchFilterMainIngredientComboBox;
    @FXML
    private ComboBox searchFilterCuisineComboBox;
    @FXML
    private RadioButton searchFilterDifficultyAllRadioButton;
    @FXML
    private RadioButton searchFilterDifficultyEasyRadioButton;
    @FXML
    private RadioButton searchFilterDifficultyMediumRadioButton;
    @FXML
    private RadioButton searchFilterDifficultyHardRadioButton;
    @FXML
    private Spinner searchFilterPriceSpinner;
    @FXML
    private Slider searchFilterTimeSlider;
    @FXML
    private Label searchFilterTimeLabel;
    @FXML
    private ImageView recipeDetailImage;
    @FXML
    private ImageView recipeDetailExitImage;
    @FXML
    private Label recipeDetailLabel;
    @FXML
    private AnchorPane recipeDetailPane;
    @FXML
    private SplitPane searchPane;
    @FXML
    private ImageView recipeDetailFlag;
    @FXML
    private Label recipeDetailPortions;
    @FXML
    private TextArea recipeDetailIngredients;
    @FXML
    private ImageView recipeDetailIngredient;
    @FXML
    private ImageView recipeDetailDifficulty;
    @FXML
    private Label recipeDetailTime;
    @FXML
    private Label recipeDetailPrice;
    @FXML
    private Label recipeDetailDescription;
    @FXML
    private TextArea recipeDetailExplain;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ComboBox ingredient = searchFilterMainIngredientComboBox;
        ComboBox cuisine = searchFilterCuisineComboBox;
        RadioButton dAll = searchFilterDifficultyAllRadioButton;
        RadioButton dEasy = searchFilterDifficultyEasyRadioButton;
        RadioButton dMedium = searchFilterDifficultyMediumRadioButton;
        RadioButton dHard = searchFilterDifficultyHardRadioButton;
        Spinner price = searchFilterPriceSpinner;
        Slider sTime = searchFilterTimeSlider;
        Label lTime = searchFilterTimeLabel;

        ingredient.getItems().add(INGREDIENT_DEFAULT);
        ingredient.getItems().addAll(Arrays.asList(backend.MAIN_INGREDIENTS));
        ingredient.getSelectionModel().select(INGREDIENT_DEFAULT);
        ingredient.getSelectionModel().selectedItemProperty().addListener((ChangeListener<String>) (ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            backend.setMainIngredient(newValue);
            updateRecipeList();
        });
        populateMainIngredientComboBox(); /////////

        cuisine.getItems().add(CUISINE_DEFAULT);
        cuisine.getItems().addAll(Arrays.asList(backend.CUISINES));
        cuisine.getSelectionModel().select(CUISINE_DEFAULT);
        cuisine.getSelectionModel().selectedItemProperty().addListener((ChangeListener<String>) (ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            backend.setCuisine(newValue);
            updateRecipeList();
        });
        populateCuisineComboBox(); ///////////

        ToggleGroup tog = new ToggleGroup();
        dAll.setToggleGroup(tog);
        dEasy.setToggleGroup(tog);
        dMedium.setToggleGroup(tog);
        dHard.setToggleGroup(tog);

        dAll.setSelected(true);

        tog.selectedToggleProperty().addListener((ChangeListener<Toggle>) (ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) -> {
            if (tog.getSelectedToggle() != null) {
                RadioButton selected = (RadioButton) tog.getSelectedToggle();
                if (selected == null) {
                    return;
                }
                backend.setDifficulty(selected.getText());
                updateRecipeList();
            }
        });

        SpinnerValueFactory<Integer> fac = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, Integer.MAX_VALUE, 0, 10);
        price.setValueFactory(fac);
        price.valueProperty().addListener((ChangeListener<Integer>) (ObservableValue<? extends Integer> observable, Integer oldValue, Integer newValue) -> {
            if (newValue == null) {
                return;
            }
            backend.setMaxPrice(newValue);
            updateRecipeList();
        });

        price.focusedProperty().addListener((ChangeListener<Boolean>) (ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) -> {
            if (newValue == null || newValue) {
                //focusgained - do nothing
            } else {
                Integer value;
                try {
                    value = Integer.valueOf(price.getEditor().getText());
                } catch (NumberFormatException e) {
                    return;
                }
                backend.setMaxPrice(value);
                updateRecipeList();
            }
        });

        sTime.valueProperty().addListener((ChangeListener<Number>) (ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
            if (newValue != null && !newValue.equals(oldValue)) {
                if (!sTime.isValueChanging()) {
                    backend.setMaxTime(newValue.intValue());
                    updateRecipeList();
                }
                lTime.setText("" + newValue.intValue() + " minuter");
            }
        });

        for (Recipe recipe : backend.getRecipes()) {
            if (recipe == null) {
                continue;
            }
            RecipeListItem recipeListItem = new RecipeListItem(recipe, this);
            recipeListItemMap.put(recipe.getName(), recipeListItem);
        }

        updateRecipeList();
        Platform.runLater(() -> ingredient.requestFocus());
    }

    private void updateRecipeList() {
        searchResultFlowPane.getChildren().clear();
        List<Recipe> r = backend.getRecipes();
        for (Recipe e : r) {
            if (e == null) {
                continue;
            }
            searchResultFlowPane.getChildren().add(recipeListItemMap.get(e.getName()));
        }
    }

    private void populateRecipeDetailView(Recipe r) {
        if (r == null) {
            return;
        }
        recipeDetailLabel.setText(r.getName());
        recipeDetailImage.setImage(getSquareImage(r.getFXImage()));
        recipeDetailFlag.setImage(getCuisineImage(r.getCuisine()));
        recipeDetailPortions.setText("" + r.getServings() + " portioner");
        String tmp = "";
        for (Ingredient e : r.getIngredients()) {
            tmp += "" + e.getAmount() + " " + e.getUnit() + " " + e.getName() + "\n";
        }
        recipeDetailIngredients.setText(tmp);
        recipeDetailIngredient.setImage(getIngredientImage(r.getMainIngredient()));
        recipeDetailDifficulty.setImage(getDifficultyImage(r.getDifficulty()));
        recipeDetailTime.setText("" + r.getTime() + " minuter");
        recipeDetailPrice.setText("" + r.getPrice() + " kr");
        recipeDetailDescription.setText(r.getDescription());
        recipeDetailExplain.setText(r.getInstruction());
    }

    @FXML
    public void closeRecipeView() {
        searchPane.toFront();
    }

    @FXML
    public void closeButtonMouseEntered() {
        recipeDetailExitImage.setImage(new Image(getClass().getClassLoader().getResourceAsStream(
                "recipesearch/resources/icon_close_hover.png")));
    }

    @FXML
    public void closeButtonMousePressed() {
        recipeDetailExitImage.setImage(new Image(getClass().getClassLoader().getResourceAsStream(
                "recipesearch/resources/icon_close_pressed.png")));
    }

    @FXML
    public void closeButtonMouseExited() {
        recipeDetailExitImage.setImage(new Image(getClass().getClassLoader().getResourceAsStream(
                "recipesearch/resources/icon_close.png")));
    }

    @FXML
    public void mouseTrap(Event event) {
        event.consume();
    }

    public void openRecipeView(Recipe recipe) {
        if (recipe == null) {
            return;
        }
        populateRecipeDetailView(recipe);
        recipeDetailPane.toFront();
    }

    private void populateMainIngredientComboBox() {
        Callback<ListView<String>, ListCell<String>> cellFactory = new Callback<ListView<String>, ListCell<String>>() {

            @Override
            public ListCell<String> call(ListView<String> p) {

                return new ListCell<String>() {

                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);

                        setText(item);

                        if (item == null || empty) {
                            setGraphic(null);
                        } else {
                            ImageView iconImageView = new ImageView(getIngredientImage(item));
                            iconImageView.setFitHeight(12);
                            iconImageView.setPreserveRatio(true);
                            setGraphic(iconImageView);
                        }
                    }
                };
            }
        };

        searchFilterMainIngredientComboBox.setButtonCell(cellFactory.call(null));
        searchFilterMainIngredientComboBox.setCellFactory(cellFactory);
    }

    private void populateCuisineComboBox() {
        Callback<ListView<String>, ListCell<String>> cellFactory = new Callback<ListView<String>, ListCell<String>>() {

            @Override
            public ListCell<String> call(ListView<String> p) {

                return new ListCell<String>() {

                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);

                        setText(item);

                        if (item == null || empty) {
                            setGraphic(null);
                        } else {
                            ImageView iconImageView = new ImageView(getCuisineImage(item));
                            iconImageView.setFitHeight(12);
                            iconImageView.setPreserveRatio(true);
                            setGraphic(iconImageView);
                        }
                    }
                };
            }
        };

        searchFilterCuisineComboBox.setButtonCell(cellFactory.call(null));
        searchFilterCuisineComboBox.setCellFactory(cellFactory);
    }
    
    public final Image getSquareImage(Image image) {
        int x = 0;
        int y = 0;
        int width = 0;
        int height = 0;

        if (image.getWidth() > image.getHeight()) {
            width = (int) image.getHeight();
            height = (int) image.getHeight();
            x = (int) (image.getWidth() - width) / 2;
            y = 0;
        } else if (image.getHeight() > image.getWidth()) {
            width = (int) image.getWidth();
            height = (int) image.getWidth();
            x = 0;
            y = (int) (image.getHeight() - height) / 2;
        } else {
            return image;
        }
        return new WritableImage(image.getPixelReader(), x, y, width, height);
    }
    
    public Image getCuisineImage(String cuisine) {
        String iconPath;
        try {
            switch (cuisine) {
                case "Sverige":
                    iconPath = "recipesearch/resources/icon_flag_sweden.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
                case "Grekland":
                    iconPath = "recipesearch/resources/icon_flag_greece.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
                case "Indien":
                    iconPath = "recipesearch/resources/icon_flag_india.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
                case "Asien":
                    iconPath = "recipesearch/resources/icon_flag_asia.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
                case "Afrika":
                    iconPath = "recipesearch/resources/icon_flag_africa.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
                case "Frankrike":
                    iconPath = "recipesearch/resources/icon_flag_france.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
            }
        } catch (NullPointerException ex) {
        }
        return null;
    }

    public Image getIngredientImage(String ingredient) {
        String iconPath;
        try {
            switch (ingredient) {

                case "Kött":
                    iconPath = "recipesearch/resources/icon_main_meat.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
                case "Fisk":
                    iconPath = "recipesearch/resources/icon_main_fish.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
                case "Kyckling":
                    iconPath = "recipesearch/resources/icon_main_chicken.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
                case "Vegetarisk":
                    iconPath = "recipesearch/resources/icon_main_veg.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
            }
        } catch (NullPointerException ex) {
        }
        return null;
    }

    public Image getDifficultyImage(String diff) {
        String iconPath;
        try {
            switch (diff) {
                case "Lätt":
                    iconPath = "recipesearch/resources/icon_difficulty_easy.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
                case "Mellan":
                    iconPath = "recipesearch/resources/icon_difficulty_medium.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
                case "Svår":
                    iconPath = "recipesearch/resources/icon_difficulty_hard.png";
                    return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
            }
        } catch (NullPointerException ex) {
        }
        return null;
    }

    public Image getTimerImage() {
        try {
            String iconPath = "recipesearch/resources/icon_time.png";
            return new Image(getClass().getClassLoader().getResourceAsStream(iconPath));
        } catch (NullPointerException ex) {
        }
        return null;
    }
}
